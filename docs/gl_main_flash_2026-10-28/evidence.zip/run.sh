#!/usr/bin/env bash
set -uo pipefail
project=/workspace/thor-deliverables
out=/workspace/thor-artifacts/gl-main-check/run-636d9b7
if [[ -e "$out" ]]; then echo 'Output exists' >&2; exit 2; fi
mkdir -p "$out"
cat > "$out/xorg.conf" <<'XCONF'
Section "Device"
 Identifier "DummyDevice"
 Driver "dummy"
 VideoRam 256000
EndSection
Section "Monitor"
 Identifier "DummyMonitor"
 HorizSync 28-80
 VertRefresh 48-75
 Modeline "1280x720" 74.25 1280 1390 1430 1650 720 725 730 750
EndSection
Section "Screen"
 Identifier "DummyScreen"
 Device "DummyDevice"
 Monitor "DummyMonitor"
 DefaultDepth 24
 SubSection "Display"
  Depth 24
  Modes "1280x720"
 EndSubSection
EndSection
XCONF
n=
for ((i=150; i<=199; i++)); do
 if [[ ! -e "/tmp/.X11-unix/X$i" && ! -e "/tmp/.X$i-lock" ]]; then n=$i; break; fi
done
if [[ -z "$n" ]]; then echo 'No free display' >&2; exit 2; fi
ulimit -c 0
/usr/lib/xorg/Xorg ":$n" -config "$out/xorg.conf" -logfile "$out/xorg.log" -noreset -nolisten tcp > "$out/server.log" 2>&1 &
server_pid=$!
cleanup() { kill "$server_pid" 2>/dev/null || true; wait "$server_pid" 2>/dev/null || true; }
trap cleanup EXIT
export DISPLAY=":$n"
ready=0
for ((i=0;i<50;i++)); do
 if xdpyinfo >/dev/null 2>&1; then ready=1; break; fi
 if ! kill -0 "$server_pid" 2>/dev/null; then break; fi
 sleep 0.2
done
if ((ready != 1)); then echo 'X server failed' >&2; exit 2; fi
printf 'commit=%s\ndisplay=%s\nstarted_utc=%s\n' "$(git -C "$project" rev-parse HEAD)" "$DISPLAY" "$(date -u +%FT%TZ)" > "$out/metadata.txt"
for scenario in enemy_flash_test enemy_flash_pixels; do
 mkdir -p "$out/$scenario/data" "$out/$scenario/cache" "$out/$scenario/config"
 args=()
 if [[ "$scenario" == enemy_flash_pixels ]]; then args=(-- "$out/frames"); fi
 XDG_DATA_HOME="$out/$scenario/data" XDG_CACHE_HOME="$out/$scenario/cache" XDG_CONFIG_HOME="$out/$scenario/config" \
  timeout --signal=TERM --kill-after=15s 600 stdbuf -oL -eL godot --path "$project" --fixed-fps 60 --audio-driver Dummy --rendering-method gl_compatibility --resolution 320x180 "res://tests/$scenario.tscn" "${args[@]}" \
  2>&1 | stdbuf -i0 -o0 head -c 50000000 > "$out/$scenario/godot.log"
 rc=$?
 printf '%s_exit=%d\n' "$scenario" "$rc" | tee -a "$out/metadata.txt"
 rg '^=== ИТОГ ENEMY FLASH:|^=== ENEMY FLASH PIXELS:|^Renderer:' "$out/$scenario/godot.log" || true
done
printf 'finished_utc=%s\n' "$(date -u +%FT%TZ)" >> "$out/metadata.txt"
