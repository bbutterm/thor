extends Node
## Изолированные сценарии проверки отложенного фокуса при обновлении экранов.
## Запускать по одному: -- <trait|choice|rune|settings>; журнал проверять на ошибки Godot.

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_run.call_deferred()

func frames(count: int = 3) -> void:
	for i in count:
		await get_tree().process_frame

func _run() -> void:
	var args := OS.get_cmdline_user_args()
	var which := str(args[0]) if not args.is_empty() else ""
	print("=== FOCUS PROBE: ", which, " ===")
	match which:
		"trait":
			await _trait_reroll()
		"choice":
			await _choice_reopen()
		"rune":
			await _rune_reopen()
		"settings":
			await _settings_rebuild()
		_:
			printerr("Unknown probe")
			get_tree().quit(2)
			return
	get_tree().paused = false
	print("=== FOCUS PROBE COMPLETE ===")
	get_tree().quit()

## Игровой путь: R сразу после открытия карточек, настоящий обработчик переброса RewardFlow.
func _trait_reroll() -> void:
	var picker := TraitPick.new()
	get_tree().root.add_child(picker)
	await frames()
	var game := Game.new()
	game.trait_pick = picker
	var flow := RewardFlow.new()
	flow.game = game
	picker.reroll_requested.connect(flow._on_trait_reroll)
	var choices: Array[MjolnirTrait] = [load("res://weapons/mjolnir_traits/fire.tres") as MjolnirTrait]
	Run.trait_rerolls = 1
	picker.open(choices)
	var old := picker._cards.get_child(0)
	var event := InputEventAction.new()
	event.action = "reload"
	event.pressed = true
	picker._unhandled_input(event)
	print("old card detached before deferred focus: ", not old.is_inside_tree(), "; rerolls left: ", Run.trait_rerolls)
	await frames()
	print("new card has focus: ", (picker._cards.get_child(0) as Button).has_focus())
	picker.queue_free()
	flow.free()
	game.free()
	await frames()

## Прямое повторное открытие публичного API в одном кадре; не утверждает, что текущие игровые потоки делают так.
func _choice_reopen() -> void:
	var picker := ChoicePick.new()
	get_tree().root.add_child(picker)
	await frames()
	var choices := [{"id": "one", "title": "Один"}]
	picker.open("Первая", "", choices)
	var old := picker._cards.get_child(0)
	picker.open("Вторая", "", choices)
	print("old card detached before deferred focus: ", not old.is_inside_tree())
	await frames()
	print("new card has focus: ", (picker._cards.get_child(0) as Button).has_focus())
	picker.queue_free()
	await frames()

## Аналогичный API двух открытий экрана рун; сценарий фиктивного повторного вызова.
func _rune_reopen() -> void:
	var picker := RunePick.new()
	get_tree().root.add_child(picker)
	await frames()
	var choices: Array[RuneDef] = [Run.rune_def("max_health")]
	picker.open(choices)
	var old := picker._cards.get_child(0)
	picker.open(choices)
	print("old card detached before deferred focus: ", not old.is_inside_tree())
	await frames()
	print("new card has focus: ", (picker._cards.get_child(0) as Button).has_focus())
	picker.queue_free()
	await frames()

## Две смены локали в одном кадре отправляют два настоящих сигнала settings.changed.
func _settings_rebuild() -> void:
	var panel := SettingsPanel.new()
	get_tree().root.add_child(panel)
	await frames()
	GameSettings.set_value("text", "language", "en")
	GameSettings.set_value("text", "language", "ru")
	await frames(6)
	print("settings still in tree: ", panel.is_inside_tree(), "; current tab: ", panel._current)
	panel.queue_free()
	await frames()
