extends Node
## Реальный бросок пике с высоты 3+ м при падении: к попаданию молота высота уже меньше 3 м.

var fails: Array[String] = []
var passes := 0

func _ready() -> void:
	_run.call_deferred()

func check(ok: bool, message: String) -> void:
	if ok:
		passes += 1
		print("  [OK] ", message)
	else:
		fails.append(message)
		print("  [FAIL] ", message)

func frames(n: int) -> void:
	for i in n:
		await get_tree().physics_frame

func _run() -> void:
	print("=== DIVE GATE TEST ===")
	Run.start_run("hunter")
	Run.add_mjolnir_trait(Run.mjolnir_trait_def(&"hammer_dive"))
	var stage := Node3D.new()
	get_tree().root.add_child(stage)
	var floor := StaticBody3D.new()
	var collider := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(100.0, 1.0, 100.0)
	collider.shape = box
	floor.add_child(collider)
	stage.add_child(floor)
	floor.global_position.y = -0.5
	var p := (load("res://player/player.tscn") as PackedScene).instantiate() as Player
	stage.add_child(p)
	p.input_enabled = false
	p.gravity = 0.0
	p.global_position = Vector3(0.0, 3.5, 0.0)
	p.rotation_target = Vector2(-0.6, 0.0)
	p.head.rotation.x = -0.6
	await frames(3)
	p.gravity = 24.0
	p.velocity.y = -10.0
	check(not p.is_on_floor() and not p._slam_ready and p.can_start_slam(), "бросок разрешён на высоте 3.5 м")
	p.mjolnir.throw_hammer()
	var proj := p.mjolnir.projectile
	check(proj != null and proj.data.get("dive", false), "реальный молот летит как пике")
	var stuck := false
	var followed := false
	var hit_height := -1.0
	for i in 60:
		await get_tree().physics_frame
		if proj != null and is_instance_valid(proj) and proj.is_stuck():
			stuck = true
			hit_height = p.global_position.y
			followed = p.is_slamming
			break
	check(stuck and hit_height > 0.1 and hit_height < p.slam_min_height,
		"молот попал, пока Тор в воздухе ниже порога (%.2f м)" % hit_height)
	check(followed, "разрешённое пике продолжается после снижения высоты")
	print("ИТОГ: %d PASS, %d FAIL" % [passes, fails.size()])
	get_tree().quit(1 if fails.size() else 0)
