extends Node
## Проверка диагностической эвристики: только отдельный тест, игровой FX не меняется.
## Счётчик считает потенциальные живые узлы по известным именам, а не реальные
## аллокации RenderingServer. Запускать только после получения отдельного GL-окна.

const IU_NAMES := ["color", "energy", "fade", "sprite", "flash", "glow", "elite"]
var failures := 0

func _ready() -> void:
	_run.call_deferred()

func _check(ok: bool, label: String) -> void:
	print("DIAG %s %s" % ["OK" if ok else "FAIL", label])
	if not ok:
		failures += 1

func _candidates(root: Node) -> int:
	var items := root.find_children("*", "GeometryInstance3D", true, false)
	if root is GeometryInstance3D:
		items.push_front(root)
	var count := 0
	for node in items:
		var gi := node as GeometryInstance3D
		var possible := FX._has_iu(gi.material_override) or FX._has_iu(gi.material_overlay)
		if not possible:
			for name in IU_NAMES:
				if gi.get_instance_shader_parameter(name) != null:
					possible = true
					break
		if possible:
			count += 1
	return count

func _frames(n: int) -> void:
	for i in n:
		await get_tree().process_frame

func _new_mesh(root: Node3D) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = FX.shared_mesh("quad")
	root.add_child(mi)
	return mi

func _run() -> void:
	print("BEGIN_INSTANCE_DIAG renderer=%s" % RenderingServer.get_current_rendering_method())
	var root := Node3D.new()
	add_child(root)
	var mi := _new_mesh(root)
	mi.material_override = FX.sprite_material("hit_flash")
	FX.sprite_color(mi, Color.WHITE)
	FX.set_sprite(mi, 0.0)
	await _frames(3)
	_check(FX.instance_uniform_users(root) == 1 and _candidates(root) == 1, "assigned material and parameter count once")
	mi.hide()
	mi.material_override = null
	await _frames(3)
	_check(FX.instance_uniform_users(root) == 0 and _candidates(root) == 1, "hidden cleared material preserves candidate history")
	mi.queue_free()
	await _frames(3)
	_check(_candidates(root) == 0, "freed node removed from estimate")

	var surface_mesh := BoxMesh.new()
	surface_mesh.material = FX.fx_material("alpha")
	var surface := MeshInstance3D.new()
	surface.mesh = surface_mesh
	root.add_child(surface)
	await _frames(3)
	_check(FX.instance_uniform_users(root) == 0 and _candidates(root) == 1, "known uniforms on mesh surface enter history")
	surface.queue_free()
	await _frames(3)

	var base := StandardMaterial3D.new()
	base.next_pass = FX.fx_material("alpha")
	var pass_mesh := _new_mesh(root)
	pass_mesh.material_override = base
	await _frames(3)
	_check(FX.instance_uniform_users(root) == 0 and _candidates(root) == 1, "known uniforms in next_pass enter history")
	pass_mesh.queue_free()
	await _frames(3)

	var no_mesh := MeshInstance3D.new()
	root.add_child(no_mesh)
	no_mesh.set_instance_shader_parameter("color", Color.RED)
	await _frames(2)
	_check(_candidates(root) == 1, "parameter on meshless node is a potential false positive")
	no_mesh.queue_free()
	await _frames(3)

	var unknown_shader := Shader.new()
	unknown_shader.code = "shader_type spatial; instance uniform float future_parameter = 0.0; void fragment(){ ALBEDO = vec3(future_parameter); }"
	var unknown_mat := ShaderMaterial.new()
	unknown_mat.shader = unknown_shader
	var unknown := _new_mesh(root)
	unknown.material_override = unknown_mat
	unknown.set_instance_shader_parameter("future_parameter", 0.5)
	await _frames(3)
	unknown.material_override = null
	await _frames(3)
	_check(_candidates(root) == 0, "known-name estimator misses cleared future uniform")
	unknown.queue_free()
	await _frames(3)

	var detached := _new_mesh(root)
	detached.set_instance_shader_parameter("color", Color.RED)
	await _frames(2)
	root.remove_child(detached)
	_check(_candidates(root) == 0 and _candidates(detached) == 1, "detached node requires explicit root")
	detached.free()
	root.queue_free()
	await _frames(3)
	print("END_INSTANCE_DIAG failures=%d" % failures)
	get_tree().quit(1 if failures else 0)
