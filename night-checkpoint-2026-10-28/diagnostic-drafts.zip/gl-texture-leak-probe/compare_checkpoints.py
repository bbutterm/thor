#!/usr/bin/env python3
"""Compare the recorded pre-exit game state; report differences, not assumed determinism."""
from __future__ import annotations
import argparse
from collections import Counter
import json
from pathlib import Path


def checkpoint(path: Path) -> dict:
    for line in (path / "godot.log").read_text(errors="replace").splitlines():
        prefix = "LEAK PROBE CHECKPOINT "
        if line.startswith(prefix):
            row = json.loads(line[len(prefix):])
            row["enemies"] = [json.loads(item) for item in row["enemies"]]
            return row
    raise ValueError(f"checkpoint not found: {path}")


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("left", type=Path)
    p.add_argument("right", type=Path)
    args = p.parse_args()
    left, right = checkpoint(args.left), checkpoint(args.right)
    keys = ["room_index", "room_path", "body", "player_health", "player_pos", "enemies", "cache_sizes", "music_track", "audio_queue", "object_nodes"]
    different = [key for key in keys if left[key] != right[key]]
    print("CHECKPOINT_EXACT_EQUAL", not different)
    print("DIFFERENT_FIELDS", ",".join(different) if different else "none")
    print("ENEMY_COUNT", len(left["enemies"]), len(right["enemies"]))
    for name, row in (("left", left), ("right", right)):
        counts = Counter((x["id"], x["kind"]) for x in row["enemies"])
        print(name.upper(), "enemy_types", sorted((str(k), v) for k, v in counts.items()))
        if different:
            print(name.upper(), json.dumps(row, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
