extends Node
## Исследовательская сцена: только диагностика очистки, не используется игрой.

const WAIT_BEFORE_SNAPSHOT := 60
const WAIT_BEFORE_CLEANUP := 6
const DEFAULT_SETTLE_FRAMES := 6
const MODES := ["direct", "unload", "direct-shot", "unload-shot", "ui-tex", "ui-scaled", "ui-theme",
	"world-mats", "world-skies", "world-ramps", "world-grades", "fx-mats", "fx-sprites", "fx-meshes",
	"screen-art", "portraits", "asset-cache"]

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	if not has_meta("runner"):
		var runner := Node.new()
		runner.set_script(get_script())
		runner.set_meta("runner", true)
		runner.name = "GLTextureLeakRunner"
		get_tree().root.add_child.call_deferred(runner)
		return
	_run.call_deferred()

func _wait_frames(n: int) -> void:
	for i in n:
		await get_tree().process_frame

func _cache_sizes() -> Dictionary:
	return {"ui_tex": UISkin._tex.size(), "ui_scaled": UISkin._scaled.size(), "ui_theme": UISkin._theme != null,
		"world_mats": WorldArt._mats.size(), "world_skies": WorldArt._skies.size(),
		"world_ramps": WorldArt._ramps.size(), "world_grades": WorldArt._grades.size(),
		"fx_mats": FX._fx_mats.size(), "fx_sprites": FX._sprite_mats.size(), "fx_meshes": FX._meshes.size(),
		"screen_cache": ScreenArt._cache.size(), "screen_pending": ScreenArt._requested.size(),
		"portrait_cache": Portrait._held.size(), "portrait_pending": Portrait._pending.size(),
		"asset_cache": AssetCache._held.size(), "asset_pending": AssetCache._pending.size()}

func _game_signature(game: Game) -> Dictionary:
	var enemies: Array[String] = []
	for enemy in game.room.alive_enemies():
		var enemy_position := enemy.global_position
		enemies.append(JSON.stringify({"kind": enemy.kind, "id": enemy.enemy_def.id if enemy.enemy_def else "",
			"health": snappedf(enemy.health, 0.001), "pos": [snappedf(enemy_position.x, 0.001), snappedf(enemy_position.y, 0.001), snappedf(enemy_position.z, 0.001)]}))
	enemies.sort()
	var player_position := game.player.global_position
	return {"room_index": Run.room_index, "room_path": Run.current_room_path(), "body": Run.body.id if Run.body else "",
		"player_health": snappedf(game.player.health, 0.001), "player_pos": [snappedf(player_position.x, 0.001), snappedf(player_position.y, 0.001), snappedf(player_position.z, 0.001)],
		"enemies": enemies, "cache_sizes": _cache_sizes(), "music_track": Music.current_track,
		"audio_queue": Audio.queue.size(), "object_nodes": int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT))}

func _clear_one(mode: String) -> void:
	match mode:
		"ui-tex": UISkin._tex.clear()
		"ui-scaled": UISkin._scaled.clear()
		"ui-theme": UISkin._theme = null
		"world-mats": WorldArt._mats.clear()
		"world-skies": WorldArt._skies.clear()
		"world-ramps": WorldArt._ramps.clear()
		"world-grades": WorldArt._grades.clear()
		"fx-mats": FX._fx_mats.clear()
		"fx-sprites": FX._sprite_mats.clear()
		"fx-meshes": FX._meshes.clear()
		"screen-art": ScreenArt.shutdown()
		"portraits": Portrait.prefetch(PackedStringArray())
		"asset-cache": AssetCache.shutdown()

func _run() -> void:
	var args := OS.get_cmdline_user_args()
	var mode := str(args[0]) if not args.is_empty() else "direct"
	var seed_value := int(args[1]) if args.size() > 1 and args[1].is_valid_int() else 20261028
	var settle_frames := int(args[2]) if args.size() > 2 and args[2].is_valid_int() else DEFAULT_SETTLE_FRAMES
	if not mode in MODES or settle_frames < 1 or settle_frames > 300 or DisplayServer.get_name() == "headless" or RenderingServer.get_current_rendering_method() != "gl_compatibility":
		printerr("LEAK PROBE FAIL: режим или renderer не подходит")
		get_tree().quit(1)
		return
	print("LEAK PROBE mode=%s seed=%d settle_frames=%d display=%s renderer=%s adapter=%s" % [mode, seed_value, settle_frames, DisplayServer.get_name(), RenderingServer.get_current_rendering_method(), RenderingServer.get_video_adapter_name()])
	seed(seed_value)
	Run.start_run("berserker")
	Run.room_order.assign([Run.ROOM_SCENES[0], Run.BOSS_SCENE])
	get_tree().change_scene_to_file("res://scenes/game.tscn")
	await _wait_frames(WAIT_BEFORE_SNAPSHOT)
	var game := get_tree().current_scene as Game
	if game == null or game.room == null or game.player == null:
		printerr("LEAK PROBE FAIL: игра/зал/игрок не готовы")
		get_tree().quit(1)
		return
	print("LEAK PROBE CHECKPOINT ", JSON.stringify(_game_signature(game), "", true))
	# За точкой сравнения удерживаем одинаковое состояние для обоих вариантов;
	# иначе при смене сцены Music автоматически переключится на меню.
	get_tree().paused = true
	Music.auto = false
	if mode.ends_with("-shot"):
		await RenderingServer.frame_post_draw
		var captured := get_viewport().get_texture().get_image()
		if captured == null or captured.is_empty():
			printerr("LEAK PROBE FAIL: viewport image пуст")
			get_tree().quit(1)
			return
		print("LEAK PROBE SCREENSHOT size=", captured.get_size())
		captured = null
	var keep_game := mode == "direct" or mode == "direct-shot"
	var original_id := game.get_instance_id()
	if not keep_game:
		var packed := PackedScene.new()
		var empty := Node.new()
		empty.name = "EmptyScene"
		var packed_rc := packed.pack(empty)
		empty.free()
		if packed_rc != OK or get_tree().change_scene_to_packed(packed) != OK:
			printerr("LEAK PROBE FAIL: смена на пустую сцену")
			get_tree().quit(1)
			return
		game = null
	await _wait_frames(WAIT_BEFORE_CLEANUP)
	if not keep_game:
		var freed := not is_instance_id_valid(original_id)
		print("LEAK PROBE GAME FREED ", freed)
		if not freed:
			printerr("LEAK PROBE FAIL: игровая сцена ещё жива")
			get_tree().quit(1)
			return
	print("LEAK PROBE BEFORE CACHE ", JSON.stringify(_cache_sizes(), "", true))
	_clear_one(mode)
	print("LEAK PROBE AFTER CACHE ", JSON.stringify(_cache_sizes(), "", true))
	await _wait_frames(settle_frames)
	await RenderingServer.frame_post_draw
	print("LEAK PROBE RESULT PASS")
	get_tree().quit(0)
