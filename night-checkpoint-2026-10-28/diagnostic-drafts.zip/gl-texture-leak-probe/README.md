# Отдельный черновой стенд очистки GL-текстур

Этот стенд подготовлен статически, пока **не импортирован и не запускался**. Он ничего не меняет в игре: после сигнала скопировать сценарий и раннер в отдельный worktree на конкретном коммите, импортировать и выполнить только там. Окружение: Linux, Godot 4.6.3, `/usr/lib/xorg/Xorg` с драйвером dummy, `xdpyinfo`, GL Compatibility. Каждая попытка использует новый каталог, отдельные X11 и `user://`, `--verbose`, 320×180 и потолок Godot-журнала 50 МБ. Исторический полный прогон и его 29/34 скачка этим коротким тестом не заменяются.

`direct` и `unload` запускают одинаковый сценарий: один seed, тело, фиксированные две сцены комнат и ровно 60 кадров до точки ветвления. На этой границе печатается `LEAK PROBE CHECKPOINT` с комнатой, телом, здоровьем/позицией игрока, видами/здоровьем/позициями врагов, количеством узлов, размерами кешей, текущим треком и длиной аудиоочереди. После этого игра ставится на паузу, а автоматический выбор музыки выключается в обоих вариантах: иначе смена на пустую сцену переключила бы трек на меню. В обоих вариантах ожидается одинаковое число кадров; `unload` в начале дополнительного ожидания меняет игру на пустую сцену и проверяет освобождение Game, `direct` сохраняет Game до штатного выхода. Число кадров и seed не гарантируют идентичности динамической сцены: для каждой пары сравнивать сохранённые checkpoint, а при различиях не выдавать их за идентичные.

После `unload` отдельный вариант может очистить **ровно один** выбранный статический кеш или одну подсистему (`screen-art`, `portraits`, `asset-cache`) в точке между одинаковыми ожиданиями; размеры до/после печатаются. Варианты `direct-shot`/`unload-shot` дополнительно читают viewport, явным образом добавляя снимок к общему сценарию. Любая очистка выполняется лишь в исследовательском процессе после освобождения Game; никаких `free_rid` и массовой очистки в продукте нет.

Дополнительное ожидание после точки очистки — 6 кадров по умолчанию; пятым аргументом раннера можно задать 1–300 кадров, например `... unload 20261028 60`. Для сравнения direct/unload задавать одинаковое значение. Увеличение ожидания — отдельный A/B, а не незаметная смена условий.

После разрешения, пример подготовки копии:

```sh
thor_base=$(git -C /workspace/thor-slam rev-parse HEAD)
git -C /workspace/thor-slam worktree add --detach /workspace/thor-gl-leak-research "$thor_base"
cp /workspace/thor-artifacts/gl-texture-leak-probe/gl_texture_leak_probe.gd /workspace/thor-gl-leak-research/tests/
cp /workspace/thor-artifacts/gl-texture-leak-probe/gl_texture_leak_probe.tscn /workspace/thor-gl-leak-research/tests/
mkdir -p /workspace/thor-artifacts/gl-texture-leak-probe/import-data
XDG_DATA_HOME=/workspace/thor-artifacts/gl-texture-leak-probe/import-data godot --headless --path /workspace/thor-gl-leak-research --import 2>&1 | head -c 50000000 > /workspace/thor-artifacts/gl-texture-leak-probe/import.log
```

Затем первые парные прогоны, не одновременно:

```sh
/workspace/thor-artifacts/gl-texture-leak-probe/run_gl_leak_probe.sh /workspace/thor-gl-leak-research /workspace/thor-artifacts/gl-texture-leak-probe/direct-1 direct 20261028
/workspace/thor-artifacts/gl-texture-leak-probe/run_gl_leak_probe.sh /workspace/thor-gl-leak-research /workspace/thor-artifacts/gl-texture-leak-probe/unload-1 unload 20261028
python3 /workspace/thor-artifacts/gl-texture-leak-probe/compare_checkpoints.py /workspace/thor-artifacts/gl-texture-leak-probe/direct-1 /workspace/thor-artifacts/gl-texture-leak-probe/unload-1
```

Повторить пары с новыми каталогами; если Game-free действительно влияет на число утечек, сравнить `unload` с индивидуальными `ui-tex`, `ui-scaled`, `ui-theme`, `world-mats`, `world-skies`, `world-ramps`, `world-grades`, `fx-mats`, `fx-sprites`, `fx-meshes`, `screen-art`, `portraits`, `asset-cache`, по одному на процесс. Скриншот проверяется отдельно парой `direct`/`direct-shot` или `unload`/`unload-shot`; из-за чтения viewport эта операция добавляет кадр и фиксируется отдельным чекпоинтом/сообщением.

`metadata.txt` разделяет код Godot, ошибки до и после строки `LEAK PROBE RESULT`, число сообщений о GL-утечках, оставшихся объектах и ObjectDB; `probe.sha256` фиксирует точные файлы сцены. Раннер откажет, если отслеживаемые файлы worktree изменены; временные неотслеживаемые файлы самого стенда допускаются. Код 0 и `RESULT PASS` подтверждают только выполнение сценарием своих проверок: при ненулевых `cleanup_errors` или ObjectDB warning процесс **не является чистым**. `--verbose` может напечатать удержанные объекты и пути, но не гарантирует соответствие конкретного GL ID пути ресурса. Не назначать причину по совпавшему размеру или одному запуску.
