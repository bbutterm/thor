#!/usr/bin/env bash
# Исследовательский стенд: запускать после эксклюзивного A/B на отдельной копии проекта.
set -uo pipefail
project=${1:-}
out=${2:-}
mode=${3:-}
seed_value=${4:-20261028}
settle_frames=${5:-6}
case "$mode" in direct|unload|direct-shot|unload-shot|ui-tex|ui-scaled|ui-theme|world-mats|world-skies|world-ramps|world-grades|fx-mats|fx-sprites|fx-meshes|screen-art|portraits|asset-cache) ;; *) mode= ;; esac
if [[ -z "$project" || -z "$out" || -z "$mode" || ! "$seed_value" =~ ^[0-9]+$ || ! "$settle_frames" =~ ^[1-9][0-9]*$ || ${#settle_frames} -gt 3 || $# -lt 3 || $# -gt 5 || -e "$out" ]] || (( 10#$settle_frames > 300 )); then
  echo 'Usage: run_gl_leak_probe.sh <project> <new-dir> <mode> [seed] [settle-frames 1..300]' >&2; exit 2
fi
for dependency in godot timeout xdpyinfo stdbuf git sha256sum; do
  if ! command -v "$dependency" >/dev/null 2>&1; then printf 'Missing dependency: %s\n' "$dependency" >&2; exit 2; fi
done
if [[ ! -x /usr/lib/xorg/Xorg ]]; then echo 'Xorg is missing: /usr/lib/xorg/Xorg' >&2; exit 2; fi
if [[ ! -d "$project" ]]; then echo 'Project directory is missing.' >&2; exit 2; fi
project=$(cd "$project" && pwd -P) || exit 2
if [[ ! -f "$project/tests/gl_texture_leak_probe.gd" || ! -f "$project/tests/gl_texture_leak_probe.tscn" ]]; then
  echo 'Probe source is missing from the isolated worktree.' >&2; exit 2
fi
if ! git -C "$project" diff --quiet || ! git -C "$project" diff --cached --quiet; then
  echo 'Tracked project files have local changes; use an isolated committed base.' >&2; exit 2
fi
mkdir -p "$out" || exit 2
out=$(cd "$out" && pwd -P)
mkdir "$out/data" "$out/cache" "$out/config"
cat > "$out/xorg.conf" <<'XCONF'
Section "Device"
    Identifier "DummyDevice"
    Driver "dummy"
    VideoRam 256000
EndSection
Section "Monitor"
    Identifier "DummyMonitor"
    HorizSync 28-80
    VertRefresh 48-75
    Modeline "1280x720" 74.25 1280 1390 1430 1650 720 725 730 750
EndSection
Section "Screen"
    Identifier "DummyScreen"
    Device "DummyDevice"
    Monitor "DummyMonitor"
    DefaultDepth 24
    SubSection "Display"
        Depth 24
        Modes "1280x720"
    EndSubSection
EndSection
XCONF
n=
for ((i=180; i<=199; i++)); do
  if [[ ! -e "/tmp/.X11-unix/X$i" && ! -e "/tmp/.X$i-lock" ]]; then n=$i; break; fi
done
if [[ -z "$n" ]]; then echo 'No free X display' >&2; exit 2; fi
ulimit -c 0
/usr/lib/xorg/Xorg ":$n" -config "$out/xorg.conf" -logfile "$out/xorg.log" -noreset -nolisten tcp > "$out/server.log" 2>&1 &
server_pid=$!
cleanup() { kill "$server_pid" 2>/dev/null || true; wait "$server_pid" 2>/dev/null || true; }
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
export DISPLAY=":$n"
ready=0
for ((i=0; i<50; i++)); do
  if xdpyinfo >/dev/null 2>&1; then ready=1; break; fi
  if ! kill -0 "$server_pid" 2>/dev/null; then break; fi
  sleep 0.2
done
if (( ready != 1 )); then echo 'X server failed' >&2; exit 2; fi
export XDG_DATA_HOME="$out/data" XDG_CACHE_HOME="$out/cache" XDG_CONFIG_HOME="$out/config"
timeout --signal=TERM --kill-after=15s 600 stdbuf -oL -eL godot --verbose --path "$project" --fixed-fps 60 --audio-driver Dummy --rendering-method gl_compatibility --resolution 320x180 res://tests/gl_texture_leak_probe.tscn -- "$mode" "$seed_value" "$settle_frames" 2>&1 | stdbuf -i0 -o0 head -c 50000000 > "$out/godot.log"
rc=$?
runtime=$(sed '/^LEAK PROBE RESULT/,$d' "$out/godot.log" | grep -cE 'ERROR:|Parse Error' || true)
cleanup_errors=$(sed -n '/^LEAK PROBE RESULT/,$p' "$out/godot.log" | grep -cE 'ERROR:|Parse Error' || true)
leaked_textures=$(grep -cE 'ERROR: Texture with GL ID of .* leaked [0-9]+ bytes' "$out/godot.log" || true)
leaked_instances=$(grep -cE '^Leaked instance:' "$out/godot.log" || true)
objectdb_warnings=$(grep -c 'ObjectDB instances leaked' "$out/godot.log" || true)
printf 'commit=%s\nmode=%s\nseed=%s\nsettle_frames=%s\nexit_code=%d\nruntime_errors=%d\ncleanup_errors=%d\nleaked_textures=%d\nleaked_instances=%d\nobjectdb_warnings=%d\n' \
  "$(git -C "$project" rev-parse HEAD)" "$mode" "$seed_value" "$settle_frames" "$rc" "$runtime" "$cleanup_errors" "$leaked_textures" "$leaked_instances" "$objectdb_warnings" | tee "$out/metadata.txt"
sha256sum "$project/tests/gl_texture_leak_probe.gd" "$project/tests/gl_texture_leak_probe.tscn" > "$out/probe.sha256"
grep -E '^LEAK PROBE (mode=|CHECKPOINT|GAME FREED|BEFORE CACHE|AFTER CACHE|SCREENSHOT|RESULT)|^ERROR: Texture with GL ID|^Resource still in use:' "$out/godot.log" || true
if (( rc != 0 || runtime != 0 )) || ! grep -q '^LEAK PROBE RESULT PASS$' "$out/godot.log" || grep -qE 'SCRIPT ERROR|Parse Error' "$out/godot.log"; then exit 1; fi
