#!/usr/bin/env python3
"""Instrument a disposable git-archive snapshot only. Never target a checkout."""
from __future__ import annotations
import argparse
from pathlib import Path
import subprocess

REV = '2a4461f463e786a721d902ab3643f1ebdc4ec6fa'
ROOT = Path('/workspace/thor-artifacts').resolve()
PROBE = 'const PAD_PROBE := preload("res://_pad_probe/metrics.gd")\n'

def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise ValueError(f'{label}: expected one occurrence, found {count}')
    return text.replace(old, new, 1)

def patch(pad: str, fx: str) -> tuple[str, str]:
    pad = replace_once(pad, 'class_name JumpPad\n', 'class_name JumpPad\n' + PROBE, 'pad class')
    fx = replace_once(fx, 'class_name FX\n', 'class_name FX\n' + PROBE, 'fx class')
    ring = '\tFX.ring(get_parent(), global_position + Vector3(0, 0.1, 0), radius * 1.8, Color(color, 0.9), 0.35)\n'
    ring_new = ('\tvar _probe_ring_start := Time.get_ticks_usec()\n'
                '\tif not PAD_PROBE.disabled("ring"):\n\t' + ring +
                '\tPAD_PROBE.record("ring", _probe_ring_start, {"radius": radius * 1.8, "lifetime": 0.35, "color": str(Color(color, 0.9))})\n')
    pad = replace_once(pad, ring, ring_new, 'pad ring')
    start = fx.index('\tvar p := CPUParticles3D.new()\n', fx.index('static func sparks('))
    end_marker = '\tt.timeout.connect(p.queue_free)\n'
    end = fx.index(end_marker, start) + len(end_marker)
    particles = fx[start:end]
    if len(particles.splitlines()) != 24 or 'p.amount = amount' not in particles:
        raise ValueError('sparks particle block changed')
    wrapped = ('\tvar _probe_particles_start := Time.get_ticks_usec()\n'
               '\tif not PAD_PROBE.disabled("particles"):\n' +
               ''.join('\t' + line for line in particles.splitlines(keepends=True)) +
               '\tPAD_PROBE.record("particles", _probe_particles_start, {"amount": amount, "speed": speed, "gravity": gravity, "size": size, "lifetime": lifetime, "color": str(color)})\n')
    fx = fx[:start] + wrapped + fx[end:]
    star_begin = '\t# Рисованные звёзды vfx_sparks_* поверх частиц — только у ярких искр (не у пыли и щепок)\n'
    fx = replace_once(fx, star_begin, '\tvar _probe_stars_start := Time.get_ticks_usec()\n' + star_begin, 'stars start')
    star_end = '\t\t\tspark_star(parent, pos + off, color, randf_range(cf.spark_size.x, cf.spark_size.y) * k)\n'
    fx = replace_once(fx, star_end, star_end + '\tPAD_PROBE.record("stars", _probe_stars_start, {"amount": amount, "expected_stars": clampi(amount / maxi(cf.sparks_per_star, 1), 1, cf.sparks_max) if color.get_luminance() >= cf.spark_min_luma and cf.sparks_max > 0 else 0, "sparks_per_star": cf.sparks_per_star, "sparks_max": cf.sparks_max})\n', 'stars end')
    entry = 'static func spark_star(parent: Node, pos: Vector3, color: Color, size: float) -> void:\n\tif parent == null or not parent.is_inside_tree():\n\t\treturn\n'
    skip = ('\t# Preserve the three global RNG calls made by the original star path.\n'
            '\tif PAD_PROBE.disabled("stars"):\n'
            '\t\tvar _probe_unused_variant := random_variant("sparks")\n'
            '\t\tvar _probe_unused_spin := randf()\n'
            '\t\tvar _probe_unused_delta := randf_range(-1.2, 1.2)\n'
            '\t\treturn\n')
    fx = replace_once(fx, entry, entry + skip, 'star diagnostic')
    return pad, fx

def git_text(repo: Path, relative: str) -> str:
    return subprocess.check_output(['git', '-C', str(repo), 'show', f'{REV}:{relative}'], text=True)

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--check-source', type=Path, help='read-only static verification against this Git repository')
    ap.add_argument('--snapshot', type=Path, help='patch only this marked archive under /workspace/thor-artifacts')
    args = ap.parse_args()
    if bool(args.check_source) == bool(args.snapshot):
        ap.error('exactly one of --check-source or --snapshot is required')
    if args.check_source:
        patch(git_text(args.check_source, 'rooms/jump_pad.gd'), git_text(args.check_source, 'scripts/fx.gd'))
        print('static source patterns match', REV)
        return
    project = args.snapshot.resolve()
    if not project.is_relative_to(ROOT) or not (project / '.padprobe-archive').is_file() or (project / '.git').exists():
        raise ValueError('refusing to patch: target is not a marked disposable archive under artifacts')
    marker = (project / '.padprobe-archive').read_text().strip()
    if marker != REV:
        raise ValueError('snapshot marker has wrong revision')
    pad_path, fx_path = project / 'rooms/jump_pad.gd', project / 'scripts/fx.gd'
    pad, fx = patch(pad_path.read_text(), fx_path.read_text())
    pad_path.write_text(pad)
    fx_path.write_text(fx)
    print('patched disposable archive', project)

if __name__ == '__main__':
    main()
