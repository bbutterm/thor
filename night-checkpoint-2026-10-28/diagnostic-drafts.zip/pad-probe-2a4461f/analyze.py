#!/usr/bin/env python3
"""Read-only evidence analysis; no run is considered clean solely from an exit code."""
from __future__ import annotations
import argparse
from collections import Counter
import json
import math
from pathlib import Path
from statistics import median

from PIL import Image, ImageChops, ImageStat

CAP = 50_000_000
SUMMARY = '=== PADPROBE RESULT:'
ERRORS = ('ERROR:', 'Parse Error', 'SCRIPT ERROR:', 'PADPROBE FAIL:')

def read_run(root: Path, name: str) -> dict:
    folder = root / name
    logfile = folder / 'godot.log'
    metricsfile = folder / 'data/ThorDostoynayaSmert/pad_metrics.json'
    if not logfile.is_file() or not metricsfile.is_file():
        raise FileNotFoundError(f'{name}: missing complete log or metrics')
    lines = logfile.read_text(errors='replace').splitlines()
    summaries = [i for i, line in enumerate(lines) if SUMMARY in line]
    end = summaries[0] if len(summaries) == 1 else None
    errors = [{'line': i + 1, 'phase': 'undetermined' if end is None else ('execution' if i < end else 'shutdown'), 'text': line}
              for i, line in enumerate(lines) if any(marker in line for marker in ERRORS)]
    shutdown_warnings = [{'line': i + 1, 'text': line} for i, line in enumerate(lines)
                         if end is not None and i > end and 'WARNING:' in line]
    meta = dict(line.split('=', 1) for line in (folder / 'metadata.txt').read_text().splitlines() if '=' in line)
    metrics = json.loads(metricsfile.read_text())
    frames = metrics['frames']
    events = []
    for trial in metrics['trials']:
        candidates = [i for i, frame in enumerate(frames)
                      if trial['start_frame'] <= int(frame[0]) <= trial['finish_frame']
                      and any(token.lstrip('*') == 'jump_pad' for token in frame[2].split(','))]
        if len(candidates) != 1:
            events.append({'trial': trial['trial'], 'event_count': len(candidates), 'frames': []})
            continue
        i = candidates[0]
        lo, hi = max(0, i - 15), min(len(frames), i + 16)
        window = sorted(float(frame[1]) for frame in frames[lo:hi])
        local = window[len(window) // 2]
        vicinity = []
        for j in range(max(0, i - 1), min(len(frames), i + 4)):
            f = frames[j]
            vicinity.append({'offset': j - i, 'frame': f[0], 'ms': f[1], 'excess_ms': f[1] - local,
                             'current': f[2], 'previous': f[3]})
        events.append({'trial': trial['trial'], 'event_count': 1, 'local_median_ms': local, 'frames': vicinity})
    segments = Counter(x['component'] for x in metrics['segments'])
    return {'name': name, 'folder': folder, 'metrics': metrics, 'events': events, 'segments': segments,
            'errors': errors, 'shutdown_warnings': shutdown_warnings, 'summary_count': len(summaries),
            'summary': lines[end] if end is not None else None, 'exit': meta.get('exit'),
            'log_bytes': logfile.stat().st_size, 'log_at_limit': logfile.stat().st_size >= CAP - 1024}

def printable(run: dict) -> dict:
    m = run['metrics']
    all_ms = [float(f[1]) for f in m['frames']]
    spikes = []
    frames = m['frames']
    for i, f in enumerate(frames):
        window = [float(row[1]) for row in frames[max(0, i - 15):min(len(frames), i + 16)]]
        window.sort()
        local = window[len(window) // 2]
        excess = float(f[1]) - local
        if excess > 50.0:
            spikes.append({'frame': f[0], 'ms': f[1], 'local_median_ms': local, 'excess_ms': excess,
                           'current': f[2], 'previous': f[3], 'marked': bool(f[2] or f[3])})
    segment_ms = {}
    for component in ('ring', 'particles', 'stars'):
        values = [float(s['cpu_wall_usec']) / 1000 for s in m['segments'] if s['component'] == component]
        segment_ms[component] = {'samples': values, 'median': median(values) if values else None}
    return {'name': run['name'], 'adapter': m['adapter'], 'renderer': m['render_method'], 'engine': m['engine'],
            'payload_pass': m['pass'], 'exit': run['exit'], 'summary': run['summary'], 'summary_count': run['summary_count'],
            'event_count_per_trial': [e['event_count'] for e in run['events']], 'events': run['events'],
            'segments': dict(run['segments']), 'segment_cpu_wall_ms': segment_ms,
            'all_frame_count': len(all_ms), 'all_frame_median_ms': median(all_ms) if all_ms else None,
            'all_spikes_gt_50ms_above_local_median': spikes,
            'errors': run['errors'], 'shutdown_warnings': run['shutdown_warnings'], 'log_bytes': run['log_bytes'],
            'log_at_limit': run['log_at_limit']}

def image_diff(a: Path, b: Path) -> dict:
    if not a.is_file() or not b.is_file():
        return {'error': 'missing image', 'a': str(a), 'b': str(b)}
    with Image.open(a) as aa, Image.open(b) as bb:
        aa, bb = aa.convert('RGB'), bb.convert('RGB')
        if aa.size != bb.size:
            return {'error': 'size mismatch', 'a_size': aa.size, 'b_size': bb.size}
        diff = ImageChops.difference(aa, bb)
        pixels = diff.get_flattened_data() if hasattr(diff, 'get_flattened_data') else diff.getdata()
        changed = sum(1 for pixel in pixels if pixel != (0, 0, 0))
        return {'size': list(aa.size), 'changed_pixels': changed, 'fraction_changed': changed / (aa.width * aa.height),
                'mean_abs_channel_delta': sum(ImageStat.Stat(diff).mean) / 3, 'exact': changed == 0}

def img(run: dict, trial: int, phase: int) -> Path:
    return run['folder'] / 'data/ThorDostoynayaSmert' / f'trial_{trial:02d}_phase_{phase:02d}.png'

def physics_comparison(a: dict, b: dict) -> dict:
    def grouped(m: dict) -> dict[int, list]:
        out = {}
        for row in m['physics_trace']:
            out.setdefault(row['trial'], []).append(row)
        return out
    x, y = grouped(a['metrics']), grouped(b['metrics'])
    counts, max_delta, value_mismatches, compared, max_numeric_delta = {}, 0.0, 0, 0, 0.0
    for trial in sorted(set(x) | set(y)):
        left, right = x.get(trial, []), y.get(trial, [])
        counts[trial] = [len(left), len(right)]
        for lhs, rhs in zip(left, right):
            compared += 1
            for key in ('position', 'velocity'):
                max_delta = max(max_delta, *(abs(float(l) - float(r)) for l, r in zip(lhs[key], rhs[key])))
            for key in ('delta', 'pad_cooldown'):
                if key in lhs and key in rhs:
                    max_numeric_delta = max(max_numeric_delta, abs(float(lhs[key]) - float(rhs[key])))
            for key in ('on_floor', 'slam_ready', 'jumps_left'):
                value_mismatches += lhs[key] != rhs[key]
    return {'sample_counts': counts, 'equal_sample_counts': bool(counts) and compared > 0 and all(a == b and a > 0 for a, b in counts.values()), 'compared_samples': compared,
            'max_vector_abs_delta': max_delta, 'max_delta_or_cooldown_abs_delta': max_numeric_delta, 'discrete_mismatches': value_mismatches,
            'saved_inputs_equal': 'inputs' in a['metrics'] and 'inputs' in b['metrics'] and a['metrics']['inputs'] == b['metrics']['inputs'],
            'trial_stimuli_equal': bool(a['metrics']['trials']) and all(all(k in t for k in ('seed', 'requested_position', 'requested_velocity')) for t in a['metrics']['trials'] + b['metrics']['trials']) and [(t['seed'], t['requested_position'], t['requested_velocity']) for t in a['metrics']['trials']] == [(t['seed'], t['requested_position'], t['requested_velocity']) for t in b['metrics']['trials']],
            'interpretation': 'Frame indices are ignored; different sample counts require investigation.'}

def snapshots(run: dict) -> list:
    return [{'trial': trial['trial'], 'phases': [x.get('effects', {}) for x in trial['snapshots']]}
            for trial in run['metrics']['trials']]

def component_counts(run: dict, component: str) -> list[list[int]]:
    values = []
    for trial in run['metrics']['trials']:
        phases = []
        for snap in trial['snapshots']:
            state = snap.get('effects', {})
            value = state.get('rings' if component == 'ring' else component, None)
            phases.append(value if isinstance(value, int) else (len(value) if isinstance(value, list) else -1))
        values.append(phases)
    return values

def visual(root: Path) -> dict:
    names = ['visual-native', 'visual-full', 'visual-no-ring', 'visual-no-particles', 'visual-no-stars']
    runs = {name: read_run(root, name) for name in names}
    native, full = runs['visual-native'], runs['visual-full']
    images = {}
    for trial in range(3):
        for phase in (1, 4, 8):
            key = f'{trial:02d}_{phase:02d}'
            images[key] = {'native_vs_instrumented_full': image_diff(img(native, trial, phase), img(full, trial, phase))}
            for c in ('ring', 'particles', 'stars'):
                images[key][f'full_vs_without_{c}'] = image_diff(img(full, trial, phase), img(runs[f'visual-no-{c}'], trial, phase))
    exact = all(item['native_vs_instrumented_full'].get('exact') is True for item in images.values())
    controls = {c: any(item[f'full_vs_without_{c}'].get('changed_pixels', 0) > 0 for item in images.values())
                for c in ('ring', 'particles', 'stars')}
    presence = {}
    for c in ('ring', 'particles', 'stars'):
        full_counts = component_counts(full, c)
        disabled_counts = component_counts(runs[f'visual-no-{c}'], c)
        presence[c] = {'full_counts': full_counts, 'disabled_counts': disabled_counts,
                       'full_present_each_trial': len(full_counts) == 3 and all(phases and max(phases) > 0 for phases in full_counts),
                       'disabled_absent_each_trial': len(disabled_counts) == 3 and all(phases and max(phases) == 0 and min(phases) >= 0 for phases in disabled_counts)}
    return {'runs': [printable(runs[n]) for n in names], 'image_comparison': images,
            'native_vs_instrumented_exact_all_phases': exact, 'positive_control_visible_changes': controls,
            'component_presence_controls': presence,
            'native_vs_instrumented_component_counts_equal': {c: bool(component_counts(native, c)) and all(phases and min(phases) >= 0 for phases in component_counts(native, c)) and component_counts(native, c) == component_counts(full, c) for c in ('ring', 'particles', 'stars')},
            'physics_native_vs_instrumented': physics_comparison(native, full),
            'physics_full_vs_diagnostics': {c: physics_comparison(full, runs[f'visual-no-{c}']) for c in ('ring', 'particles', 'stars')},
            'visible_effect_node_states': {name: snapshots(run) for name, run in runs.items()},
            'interpretation': 'Exact pixel differences require inspection, including particle stochasticity and timing; pixel changes alone do not prove component-specific differences. Do not proceed automatically.'}

def aa(root: Path) -> dict:
    runs = [read_run(root, name) for name in ('aa-full-A1', 'aa-full-A2')]
    return {'runs': [printable(run) for run in runs], 'physics_A1_vs_A2': physics_comparison(runs[0], runs[1]),
            'interpretation': 'Compare the per-trial event and neighboring frame samples with unmarked peaks and normal process-to-process variation. No causal or automatic pass claim.'}

def bench(root: Path, component: str) -> dict:
    names = [f'bench-{component}-{part}' for part in ('A1', 'B1', 'B2', 'A2')]
    runs = [read_run(root, name) for name in names]
    return {'runs': [printable(run) for run in runs],
            'physics_A1_vs_A2': physics_comparison(runs[0], runs[3]),
            'physics_A1_vs_B1': physics_comparison(runs[0], runs[1]),
            'interpretation': 'Diagnostics remove a visible component and can change other RNG consumers. Frame excess is based on the local 31-sample median. Inspect A/A variation, all frames, audio and component state; CPU timing is not GPU timing.'}

def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument('staged_directory', type=Path)
    p.add_argument('mode', choices=('visual', 'aa', 'bench'))
    p.add_argument('--component', choices=('particles', 'ring', 'stars'), default='particles')
    args = p.parse_args()
    out = visual(args.staged_directory) if args.mode == 'visual' else (aa(args.staged_directory) if args.mode == 'aa' else bench(args.staged_directory, args.component))
    print(json.dumps(out, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
