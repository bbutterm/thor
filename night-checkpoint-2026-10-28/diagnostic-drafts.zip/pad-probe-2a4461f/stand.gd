extends Node3D
## Disposable benchmark scene. Uses actual project Player, JumpPad, FX and Audio.
## Other than saved teleports, no player input is injected.
const PROBE := preload("res://_pad_probe/metrics.gd")
const PLAYER_SCENE := preload("res://player/player.tscn")
const PHASES := [1, 4, 8]

var player: Player
var pad: JumpPad
var room: Node = null             # ShaderWarmup reads this from its game node.
var tutorial: Tutorial = null
var active_trial: int = -1
var physics_trace: Array = []
var trials: Array = []
var captures: Array = []
var inputs: Dictionary = {}

func _ready() -> void:
	_run.call_deferred()

func _physics_process(delta: float) -> void:
	if active_trial < 0 or not is_instance_valid(player) or not is_instance_valid(pad):
		return
	physics_trace.append({
		"trial": active_trial,
		"process_frame": Engine.get_process_frames(),
		"physics_frame": Engine.get_physics_frames(),
		"delta": delta,
		"position": _vec(player.global_position),
		"velocity": _vec(player.velocity),
		"on_floor": player.is_on_floor(),
		"pad_cooldown": pad._cd,
		"slam_ready": player._slam_ready,
		"jumps_left": player._jumps_left,
	})

func _vec(v: Vector3) -> Array:
	return [v.x, v.y, v.z]

func _array_vec(v: Array) -> Vector3:
	return Vector3(float(v[0]), float(v[1]), float(v[2]))

func _wait_physics(n: int) -> void:
	for _i in n:
		await get_tree().physics_frame

func _wait_process(n: int) -> void:
	for _i in n:
		await get_tree().process_frame

func _make_floor() -> void:
	var body := StaticBody3D.new()
	body.name = "ProbeFloor"
	body.position = Vector3(0, -0.5, 0)
	body.collision_layer = 1
	var shape := BoxShape3D.new()
	shape.size = Vector3(20, 1, 20)
	var collision := CollisionShape3D.new()
	collision.shape = shape
	body.add_child(collision)
	var mesh := BoxMesh.new()
	mesh.size = shape.size
	var surface := MeshInstance3D.new()
	surface.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.19, 0.24, 0.31)
	surface.material_override = mat
	body.add_child(surface)
	add_child(body)

func _snapshot_effects() -> Dictionary:
	var rings := 0
	var particle_nodes: Array = []
	for child in get_children():
		if child is MeshInstance3D and child.mesh == FX.shared_mesh("ring"):
			rings += 1
		if child is CPUParticles3D:
			var p := child as CPUParticles3D
			particle_nodes.append({"emitting": p.emitting, "amount": p.amount,
				"lifetime": p.lifetime, "spread": p.spread, "gravity": _vec(p.gravity),
				"velocity_min": p.initial_velocity_min, "velocity_max": p.initial_velocity_max,
				"scale_min": p.scale_amount_min, "scale_max": p.scale_amount_max})
	var stars: Array = []
	for item in FX.pool_nodes("sparks"):
		var s := item as MeshInstance3D
		if s.visible:
			var material := s.material_override as ShaderMaterial
			var texture: Texture2D = material.get_shader_parameter("tex") if material else null
			stars.append({"texture": texture.resource_path if texture else "",
				"position": _vec(s.global_position), "scale": _vec(s.scale),
				"transparency": s.transparency, "sprite": str(s.get_meta("sp", ""))})
	var playing: Array = []
	for child in Audio.get_children():
		if child is AudioStreamPlayer and child.playing:
			var a := child as AudioStreamPlayer
			playing.append({"stream": a.stream.resource_path if a.stream else "", "pitch": a.pitch_scale})
	return {"rings": rings, "particles": particle_nodes, "stars": stars,
		"audio_queue": Audio.queue.size(), "audio_playing": playing}

func _run() -> void:
	var args := OS.get_cmdline_user_args()
	var variant := args[0] if args.size() > 0 else "full"
	var repetitions := args[1].to_int() if args.size() > 1 else 3
	var capture_visual := args.size() > 2 and args[2] == "visual"
	if variant not in ["full", "without_ring", "without_particles", "without_stars"] or repetitions < 1 or repetitions > 100:
		printerr("PADPROBE FAIL: invalid arguments")
		get_tree().quit(2)
		return
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://_pad_probe/inputs.json"))
	if not parsed is Dictionary or not parsed.has("seeds") or repetitions > parsed.seeds.size():
		printerr("PADPROBE FAIL: invalid saved inputs or too many repetitions")
		get_tree().quit(2)
		return
	inputs = parsed
	PROBE.variant = variant
	Run.start_run("berserker")
	AssetCache.start()
	AssetCache.finish()
	_make_floor()
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-55, -30, 0)
	add_child(light)
	player = PLAYER_SCENE.instantiate() as Player
	player.name = "ActualPlayer"
	player.position = _array_vec(inputs.park_position)
	add_child(player)
	player.apply_body_and_runes(Run.body, Run)
	player.input_enabled = false
	pad = JumpPad.new()
	pad.name = "ActualJumpPad"
	add_child(pad)
	var camera := Camera3D.new()
	camera.position = _array_vec(inputs.camera_position)
	add_child(camera)
	camera.look_at(_array_vec(inputs.camera_target), Vector3.UP)
	camera.current = true
	ShaderWarmup.run(self)
	await _wait_process(35)
	await _wait_physics(10)
	Perf.frames.clear()
	Perf.record_all = true
	var passed := true
	for index in repetitions:
		active_trial = -1
		PROBE.active = false
		player.global_position = _array_vec(inputs.park_position)
		player.velocity = _array_vec(inputs.velocity)
		await _wait_physics(int(inputs.park_physics_frames))
		if pad._cd > 0.0 or player.is_dead:
			printerr("PADPROBE FAIL: player/cooldown precondition trial=", index)
			passed = false
			break
		# All variants get exactly the same teleported start and seed. The pad and
		# player then run the normal physics and collision code without inputs.
		var trial_seed: int = int(inputs.seeds[index])
		seed(trial_seed)
		PROBE.trial = index
		PROBE.active = true
		active_trial = index
		var f0 := Engine.get_process_frames()
		var phys0 := Engine.get_physics_frames()
		player.global_position = pad.global_position + _array_vec(inputs.pad_offset)
		player.velocity = _array_vec(inputs.velocity)
		var entry := {"trial": index, "seed": trial_seed, "requested_position": _vec(player.global_position),
			"requested_velocity": _vec(player.velocity), "start_frame": f0, "start_physics_frame": phys0,
			"audio_queue_before": Audio.queue.size(), "snapshots": []}
		var launched := false
		for _i in 30:
			await get_tree().physics_frame
			if pad._cd > 0.0:
				launched = true
				break
		if not launched:
			printerr("PADPROBE FAIL: actual pad did not activate trial=", index)
			passed = false
			break
		entry["detected_frame"] = Engine.get_process_frames()
		entry["detected_physics_frame"] = Engine.get_physics_frames()
		entry["detected_velocity"] = _vec(player.velocity)
		PROBE.active = false
		var phase := 0
		for _i in PHASES[-1]:
			await get_tree().process_frame
			await RenderingServer.frame_post_draw
			phase += 1
			if phase in PHASES:
				var snap := {"phase": phase, "frame": Engine.get_process_frames()}
				if capture_visual:
					snap["effects"] = _snapshot_effects()
					var image := get_viewport().get_texture().get_image()
					captures.append({"trial": index, "phase": phase, "image": image})
				entry["snapshots"].append(snap)
		await _wait_physics(int(inputs.after_detection_physics_frames))
		active_trial = -1
		entry["finish_frame"] = Engine.get_process_frames()
		entry["finish_physics_frame"] = Engine.get_physics_frames()
		trials.append(entry)
	Perf.record_all = false
	PROBE.active = false
	var payload := {"variant": variant, "visual": capture_visual, "repetitions_requested": repetitions,
		"trials": trials, "physics_trace": physics_trace, "frames": Perf.frames,
		"segments": PROBE.segments, "pass": passed and trials.size() == repetitions,
		"render_method": RenderingServer.get_current_rendering_method(),
		"adapter": RenderingServer.get_video_adapter_name(), "engine": Engine.get_version_info().string,
		"vfx_config": {"sparks_max": FX.cfg().sparks_max, "sparks_per_star": FX.cfg().sparks_per_star,
			"spark_min_luma": FX.cfg().spark_min_luma},
		"inputs": inputs,
		"pad": {"height": pad.height, "radius": pad.radius, "cooldown": pad.cooldown, "color": str(pad.color)}}
	var file := FileAccess.open("user://pad_metrics.json", FileAccess.WRITE)
	if file == null:
		printerr("PADPROBE FAIL: cannot write metrics")
		get_tree().quit(2)
		return
	file.store_string(JSON.stringify(payload))
	file.close()
	for capture in captures:
		var path := "user://trial_%02d_phase_%02d.png" % [capture.trial, capture.phase]
		var rc := (capture.image as Image).save_png(path)
		if rc != OK:
			printerr("PADPROBE FAIL: cannot save ", path)
			passed = false
	print("=== PADPROBE RESULT: %s trials=%d variant=%s visual=%s ===" % ["PASS" if passed else "FAIL", trials.size(), variant, capture_visual])
	FX.reset_time()
	get_tree().quit(0 if passed else 1)
