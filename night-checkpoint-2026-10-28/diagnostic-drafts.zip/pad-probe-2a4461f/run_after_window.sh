#!/usr/bin/env bash
# PREPARED ONLY. Needs exclusive Xorg/Godot window; never run while another graphics test is active.
# Usage: run_after_window.sh STAGED_DIR visual | aa | bench [particles|ring|stars]
set -u -o pipefail
umask 077
project_root=${1:?pass staged directory}
mode=${2:?visual or bench}
component=${3:-particles}
case "$project_root" in /workspace/thor-artifacts/*) ;; *) printf 'unsafe output path\n' >&2; exit 2;; esac
case "$mode" in visual|aa|bench) ;; *) printf 'bad mode\n' >&2; exit 2;; esac
case "$component" in particles|ring|stars) ;; *) printf 'bad component\n' >&2; exit 2;; esac
for project in "$project_root/original" "$project_root/instrumented"; do
    [[ -f "$project/.padprobe-archive" && -f "$project/project.godot" ]] || { printf 'missing archive marker/project\n' >&2; exit 2; }
done
ulimit -c 0
# Bash ulimit -f uses 1024-byte blocks: 48,828 blocks = 49,999,872 bytes.
ulimit -f 48828
import_project() {
    local project=$1 label=$2 run="$project_root/import-$2"
    if [[ -e "$run" ]]; then printf 'import output already exists: %s\n' "$run" >&2; return 2; fi
    mkdir -p "$run/data" "$run/config" "$run/cache" "$run/runtime"
    chmod 700 "$run/runtime"
    local rc=0
    XDG_DATA_HOME="$run/data" XDG_CONFIG_HOME="$run/config" XDG_CACHE_HOME="$run/cache" XDG_RUNTIME_DIR="$run/runtime" \
        timeout --signal=TERM --kill-after=20s 1200 godot --headless --editor --import --quit --path "$project" > "$run/godot.log" 2>&1 || rc=$?
    printf 'exit=%d\n' "$rc" > "$run/metadata.txt"
    if [[ "$rc" != 0 ]] || rg -n 'ERROR:|Parse Error|SCRIPT ERROR:' "$run/godot.log"; then
        printf 'Import %s requires review: %s\n' "$label" "$run/godot.log" >&2
        return 1
    fi
}
if [[ "$mode" == visual ]]; then
    import_project "$project_root/original" original || exit 1
    import_project "$project_root/instrumented" instrumented || exit 1
else
    [[ -d "$project_root/original/.godot/imported" && -d "$project_root/instrumented/.godot/imported" ]] || { printf 'perform visual/import first\n' >&2; exit 2; }
fi
xdir="$project_root/xorg-$mode${component}"
[[ ! -e "$xdir" ]] || { printf 'already exists: %s\n' "$xdir" >&2; exit 2; }
mkdir -p "$xdir"
cat > "$xdir/xorg.conf" <<'XCONF'
Section "Device"
    Identifier "DummyDevice"
    Driver "dummy"
    VideoRam 256000
EndSection
Section "Monitor"
    Identifier "DummyMonitor"
    HorizSync 28-80
    VertRefresh 48-75
    Modeline "1280x720" 74.25 1280 1390 1430 1650 720 725 730 750
EndSection
Section "Screen"
    Identifier "DummyScreen"
    Device "DummyDevice"
    Monitor "DummyMonitor"
    DefaultDepth 24
    SubSection "Display"
        Depth 24
        Modes "1280x720"
    EndSubSection
EndSection
XCONF
display_num=
for n in $(seq 101 199); do
    if [[ ! -e "/tmp/.X11-unix/X$n" && ! -e "/tmp/.X$n-lock" ]]; then display_num=$n; break; fi
done
[[ -n "$display_num" ]] || { printf 'no free display\n' >&2; exit 2; }
/usr/lib/xorg/Xorg ":$display_num" -noreset -nolisten tcp -config "$xdir/xorg.conf" -logfile "$xdir/xorg.log" > "$xdir/server.log" 2>&1 &
xpid=$!
cleanup() { kill "$xpid" 2>/dev/null || true; wait "$xpid" 2>/dev/null || true; }
trap cleanup EXIT
export DISPLAY=":$display_num" LIBGL_ALWAYS_SOFTWARE=1 GALLIUM_DRIVER=llvmpipe
ready=0
for ((i=0; i<50; i++)); do
    if xdpyinfo >/dev/null 2>&1; then ready=1; break; fi
    if ! kill -0 "$xpid" 2>/dev/null; then break; fi
    sleep 0.2
done
[[ "$ready" == 1 ]] || { printf 'Xorg failed, see %s\n' "$xdir" >&2; exit 2; }
status=0
run_one() {
    local label=$1 project=$2 variant=$3 repetitions=$4 capture=$5
    local run="$project_root/$label" rc=0
    if [[ -e "$run" ]]; then printf 'run output exists: %s\n' "$run" >&2; return 2; fi
    mkdir -p "$run/data" "$run/cache" "$run/config" "$run/runtime"
    chmod 700 "$run/runtime"
    printf 'project=%s\nvariant=%s\nrepetitions=%s\ncapture=%s\ndisplay=%s\nstarted_utc=%s\n' \
        "$project" "$variant" "$repetitions" "$capture" "$DISPLAY" "$(date -u +%FT%TZ)" > "$run/metadata.txt"
    XDG_DATA_HOME="$run/data" XDG_CACHE_HOME="$run/cache" XDG_CONFIG_HOME="$run/config" XDG_RUNTIME_DIR="$run/runtime" \
        timeout --signal=TERM --kill-after=30s 1200 godot --path "$project" --fixed-fps 60 --audio-driver Dummy \
        --rendering-method gl_compatibility --resolution 320x180 res://_pad_probe/stand.tscn -- \
        "$variant" "$repetitions" "$capture" > "$run/godot.log" 2>&1 || rc=$?
    printf 'finished_utc=%s\nexit=%d\n' "$(date -u +%FT%TZ)" "$rc" >> "$run/metadata.txt"
    printf '%s exit=%d; complete log: %s\n' "$label" "$rc" "$run/godot.log"
    # A broken scene/parse stops the sequence immediately; keep all logs.
    # Any post-result errors are retained and flagged, without rewriting them.
    if ! python3 - "$run/godot.log" <<'PYCHECK'
import sys
from pathlib import Path
p = Path(sys.argv[1])
lines = p.read_text(errors='replace').splitlines()
result = [i for i, s in enumerate(lines) if '=== PADPROBE RESULT:' in s]
errors = ('ERROR:', 'SCRIPT ERROR:', 'Parse Error', 'PADPROBE FAIL:')
if len(result) != 1 or 'PADPROBE RESULT: PASS' not in lines[result[0]]:
    print('Missing/failed/duplicate result:', p, file=sys.stderr)
    sys.exit(1)
if any(any(marker in s for marker in errors) for s in lines[:result[0]]):
    print('Execution errors before result:', p, file=sys.stderr)
    sys.exit(1)
if p.stat().st_size >= 49_998_976:
    print('Log may be capped:', p, file=sys.stderr)
    sys.exit(1)
PYCHECK
    then
        status=1
        return 1
    fi
    if [[ "$rc" != 0 ]] || rg -n 'ERROR:|Parse Error|SCRIPT ERROR:|PADPROBE FAIL:' "$run/godot.log"; then status=1; fi
}
if [[ "$mode" == visual ]]; then
    run_one visual-native "$project_root/original" full 3 visual || exit 1
    run_one visual-full "$project_root/instrumented" full 3 visual || exit 1
    run_one visual-no-ring "$project_root/instrumented" without_ring 3 visual || exit 1
    run_one visual-no-particles "$project_root/instrumented" without_particles 3 visual || exit 1
    run_one visual-no-stars "$project_root/instrumented" without_stars 3 visual || exit 1
elif [[ "$mode" == aa ]]; then
    # Independent full runs quantify normal variation before any component is removed.
    run_one aa-full-A1 "$project_root/instrumented" full 16 benchmark || exit 1
    run_one aa-full-A2 "$project_root/instrumented" full 16 benchmark || exit 1
else
    # Run only after visual gate and repeatable candidate hitches pass A/A noise checks.
    [[ -f "$project_root/aa-full-A1/data/ThorDostoynayaSmert/pad_metrics.json" && -f "$project_root/aa-full-A2/data/ThorDostoynayaSmert/pad_metrics.json" ]] || { printf 'A/A outputs missing; run aa and inspect first\n' >&2; exit 2; }
    run_one "bench-${component}-A1" "$project_root/instrumented" full 16 benchmark || exit 1
    run_one "bench-${component}-B1" "$project_root/instrumented" "without_$component" 16 benchmark || exit 1
    run_one "bench-${component}-B2" "$project_root/instrumented" "without_$component" 16 benchmark || exit 1
    run_one "bench-${component}-A2" "$project_root/instrumented" full 16 benchmark || exit 1
fi
printf 'Inspect every log and compare with analyze.py before interpreting results.\n'
exit "$status"
