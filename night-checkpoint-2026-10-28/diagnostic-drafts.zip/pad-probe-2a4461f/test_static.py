#!/usr/bin/env python3
"""Tiny synthetic tests for the static parser and disposable instrumentation generator.
No Godot or project import. The game checkout is read only.
"""
from __future__ import annotations
import json
from pathlib import Path
import tempfile
import unittest

from PIL import Image
import analyze
import patch

class DiagnosticsTest(unittest.TestCase):
    def test_patch_is_revision_scoped_and_contains_three_components(self):
        repo = Path('/workspace/thor-slam')
        pad = patch.git_text(repo, 'rooms/jump_pad.gd')
        fx = patch.git_text(repo, 'scripts/fx.gd')
        result_pad, result_fx = patch.patch(pad, fx)
        self.assertEqual(result_pad.count('PAD_PROBE.record("ring"'), 1)
        self.assertEqual(result_fx.count('PAD_PROBE.record("particles"'), 1)
        self.assertEqual(result_fx.count('PAD_PROBE.record("stars"'), 1)
        self.assertIn('if PAD_PROBE.disabled("stars"):', result_fx)
        with self.assertRaises(ValueError):
            patch.patch(pad.replace('class_name JumpPad', 'class_name Different'), fx)

    def _fake_run(self, root: Path, name: str, color: int = 0) -> None:
        folder = root / name
        data = folder / 'data/ThorDostoynayaSmert'
        data.mkdir(parents=True)
        (folder / 'metadata.txt').write_text('exit=1\n')
        (folder / 'godot.log').write_text('prefix ERROR: execution\n=== PADPROBE RESULT: PASS ===\ntext ERROR: exit\nWARNING: resource\n')
        frames = [[i, 100.0 if i == 5 else (90.0 if i == 15 else 10.0), 'jump_pad' if i == 15 else '', ''] for i in range(31)]
        trials, physics = [], []
        for i in range(3):
            trials.append({'trial': i, 'start_frame': 10, 'finish_frame': 20,
                           'snapshots': [{'phase': x, 'effects': {}} for x in (1, 4, 8)]})
            physics.append({'trial': i, 'position': [0, 1, 0], 'velocity': [0, 2, 0],
                            'on_floor': False, 'slam_ready': True, 'jumps_left': 1})
            for phase in (1, 4, 8):
                Image.new('RGB', (2, 2), (color, 0, 0)).save(data / f'trial_{i:02d}_phase_{phase:02d}.png')
        metrics = {'variant': 'full', 'visual': True, 'repetitions_requested': 3, 'trials': trials,
                   'physics_trace': physics, 'frames': frames, 'segments': [], 'pass': True,
                   'render_method': 'gl_compatibility', 'adapter': 'synthetic', 'engine': 'synthetic'}
        (data / 'pad_metrics.json').write_text(json.dumps(metrics))

    def test_inline_errors_event_accounting_and_unmarked(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self._fake_run(root, 'test')
            run = analyze.read_run(root, 'test')
            self.assertEqual([x['phase'] for x in run['errors']], ['execution', 'shutdown'])
            self.assertEqual(len(run['shutdown_warnings']), 1)
            self.assertEqual([x['event_count'] for x in run['events']], [1, 1, 1])
            spikes = analyze.printable(run)['all_spikes_gt_50ms_above_local_median']
            self.assertEqual([x['marked'] for x in spikes], [False, True])
            self.assertEqual([x['excess_ms'] for x in spikes], [90.0, 80.0])
            self.assertTrue(analyze.physics_comparison(run, run)['equal_sample_counts'])
            run['metrics']['physics_trace'] = []
            self.assertFalse(analyze.physics_comparison(run, run)['equal_sample_counts'])

    def test_visual_detects_unchanged_baseline_and_positive_controls(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self._fake_run(root, 'visual-native')
            self._fake_run(root, 'visual-full')
            for name in ('visual-no-ring', 'visual-no-particles', 'visual-no-stars'):
                self._fake_run(root, name, color=20)
            report = analyze.visual(root)
            self.assertTrue(report['native_vs_instrumented_exact_all_phases'])
            self.assertTrue(all(report['positive_control_visible_changes'].values()))
            self.assertTrue(report['physics_native_vs_instrumented']['equal_sample_counts'])
            image = root / 'visual-full/data/ThorDostoynayaSmert/trial_00_phase_01.png'
            Image.new('RGB', (2, 2), (30, 0, 0)).save(image)
            self.assertFalse(analyze.visual(root)['native_vs_instrumented_exact_all_phases'])

if __name__ == '__main__':
    unittest.main(verbosity=2)
