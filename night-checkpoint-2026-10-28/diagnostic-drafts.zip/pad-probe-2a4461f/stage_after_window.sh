#!/usr/bin/env bash
# PREPARED ONLY. Do not execute until the exclusive graphics window is free.
# Usage: stage_after_window.sh /workspace/thor-slam /workspace/thor-artifacts/pad-probe-run-UNIQUE
set -euo pipefail
umask 077
src=${1:?pass existing git repository}
out=${2:?pass a NEW artifacts directory}
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
revision=2a4461f463e786a721d902ab3643f1ebdc4ec6fa
case "$out" in /workspace/thor-artifacts/*) ;; *) printf 'output must be under artifacts\n' >&2; exit 2;; esac
[[ ! -e "$out" ]] || { printf 'output already exists: %s\n' "$out" >&2; exit 2; }
git -C "$src" cat-file -e "$revision^{commit}"
python3 "$here/patch.py" --check-source "$src"
mkdir -p "$out/original" "$out/instrumented"
# This creates snapshots, not Git worktrees; no file in the checkout is written.
git -C "$src" archive --format=tar "$revision" | tar -xf - -C "$out/original"
printf '%s\n' "$revision" > "$out/original/.padprobe-archive"
cp -a --reflink=auto "$out/original/." "$out/instrumented/"
for project in "$out/original" "$out/instrumented"; do
    mkdir -p "$project/_pad_probe"
    for f in metrics.gd stand.gd stand.tscn inputs.json; do
        cp "$here/$f" "$project/_pad_probe/$f"
    done
done
python3 "$here/patch.py" --snapshot "$out/instrumented"
{
    printf 'source_commit=%s\n' "$revision"
    printf 'source_repository=%s\n' "$src"
    printf 'staged_utc=%s\n' "$(date -u +%FT%TZ)"
    sha256sum "$here"/{metrics.gd,stand.gd,stand.tscn,inputs.json,patch.py,stage_after_window.sh,run_after_window.sh,analyze.py}
    sha256sum "$out/original"/{rooms/jump_pad.gd,scripts/fx.gd}
    sha256sum "$out/instrumented"/{rooms/jump_pad.gd,scripts/fx.gd}
} > "$out/staging.txt"
printf 'Staged snapshots: %s\nNext: %s/run_after_window.sh %s visual\n' "$out" "$here" "$out"
