extends RefCounted
## Test-only, shared between the copied scene and its instrumented scripts.
static var active: bool = false
static var trial: int = -1
static var variant: String = "full"
static var segments: Array = []

static func disabled(component: String) -> bool:
	return active and variant == "without_" + component

static func record(component: String, started_usec: int, details: Dictionary = {}) -> void:
	if not active:
		return
	segments.append({
		"trial": trial,
		"component": component,
		"cpu_wall_usec": Time.get_ticks_usec() - started_usec,
		"process_frame": Engine.get_process_frames(),
		"physics_frame": Engine.get_physics_frames(),
		"disabled": disabled(component),
		"details": details,
	})
